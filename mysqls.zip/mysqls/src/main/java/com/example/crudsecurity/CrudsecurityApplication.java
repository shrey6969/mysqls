package com.example.crudsecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudsecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudsecurityApplication.class, args);
	}

}
