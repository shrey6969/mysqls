package com.example.crudsecurity.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.crudsecurity.model.Student;

public interface StudentRepo extends CrudRepository<Student,Integer> {

}
